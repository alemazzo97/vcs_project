#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 12:06:03 2020

@author: alessio arcudi, alessandro mazzoni, alessandro padella
"""


import keras
import cv2
import os
import numpy as np
import random
import matplotlib.pyplot as plt
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten, Reshape
from keras.layers.convolutional import Convolution1D, Convolution2D, MaxPooling2D
from keras.utils import np_utils
from keras.layers import Conv2D
from keras.layers import MaxPool3D
import tensorflow as tf
from sklearn.model_selection import train_test_split
from keras.optimizers import Adam



        
def batch_generator(x, y, batch_size=32):
    n_batches_per_epoch = x.shape[0]//batch_size
    for i in range(n_batches_per_epoch):
        index_batch = range(x.shape[0])[batch_size*i:batch_size*(i+1)]       
        x_batch = x[index_batch,:]
        y_batch = y[index_batch,:]
        yield x_batch, np.array(y_batch)
        

def vanilla_model(input_shape,n_label):
    model = Sequential()
    model.add(Dense(12, activation='relu', input_shape=(22, 360, 640, 3)))
    model.add(Dense(n_label, activation='softmax'))


    model.compile(loss='binary_crossentropy', optimizer='adadelta', metrics='categorical_accuracy')
    return model


def VGG16(input_shape,n_classes):
    model = Sequential()
    
    model.add(Conv2D(input_shape=input_shape,filters=64,kernel_size=(3,3),padding="same", activation="relu"))
    model.add(Conv2D(filters=64,kernel_size=(3,3),padding="same", activation="relu"))
    model.add(MaxPool3D(pool_size=(2,2,2),strides=None,data_format = 'channels_first'))
    
    model.add(Conv2D(filters=128, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=128, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(MaxPool3D(pool_size=(2,2,2),strides=None,data_format = 'channels_first'))
    
    model.add(Conv2D(filters=256, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=256, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=256, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(MaxPool3D(pool_size=(2,2,2),strides=None,data_format = 'channels_first'))
    
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(MaxPool3D(pool_size=(2,2,2),strides=None,data_format = 'channels_first'))
    
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(Conv2D(filters=512, kernel_size=(3,3), padding="same", activation="relu"))
    model.add(MaxPool3D(pool_size=(2,2,2),strides=None,data_format = 'channels_first'))
    
    model.add(Flatten())
    model.add(Dense(units=4096,activation="relu"))
    model.add(Dense(units=4096,activation="relu"))
    model.add(Dense(units=n_classes, activation="softmax"))
    
    opt = Adam(lr=0.001)
    model.compile(optimizer=opt, loss=keras.losses.categorical_crossentropy, metrics='categorical_accuracy')
    return model


from keras.layers import Conv3D,BatchNormalization, MaxPool2D, GlobalMaxPool3D
def build_convnet2(input_shape):
    momentum = .9
    model = keras.Sequential()
    model.add(Conv3D(64, (3,3,3), input_shape=input_shape, padding='same', activation='relu'))
    model.add(Conv3D(64, (3,3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool3D())
    
    model.add(Conv3D(128, (3,3,3), padding='same', activation='relu'))
    model.add(Conv3D(128, (3,3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool3D())
    
    model.add(Conv3D(256, (3,3,3), padding='same', activation='relu'))
    model.add(Conv3D(256, (3,3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool3D())
    
    model.add(Conv3D(512, (3,3,3), padding='same', activation='relu'))
    model.add(Conv3D(512, (3,3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    # flatten...
    model.add(GlobalMaxPool3D())
    return model

def build_convnet(shape=(112, 112, 3)):
    momentum = .9
    model = keras.Sequential()
    model.add(Conv2D(64, (3,3), input_shape=shape,
        padding='same', activation='relu'))
    model.add(Conv2D(64, (3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool2D())
    
    model.add(Conv2D(128, (3,3), padding='same', activation='relu'))
    model.add(Conv2D(128, (3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool2D())
    
    model.add(Conv2D(256, (3,3), padding='same', activation='relu'))
    model.add(Conv2D(256, (3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    model.add(MaxPool2D())
    
    model.add(Conv2D(512, (3,3), padding='same', activation='relu'))
    model.add(Conv2D(512, (3,3), padding='same', activation='relu'))
    model.add(BatchNormalization(momentum=momentum))
    
    # flatten...
    model.add(GlobalMaxPool2D())
    return model

from keras.layers import TimeDistributed, GRU, LSTM,GlobalMaxPool2D
def action_model(input_shape,nclasses):
    # Create our convnet with (112, 112, 3) input shape
    convnet = build_convnet(input_shape[1:])
    
    # then create our final model
    model = keras.Sequential()
    # add the convnet with (5, 112, 112, 3) shape
    model.add(TimeDistributed(convnet, input_shape=input_shape))
    # here, you can also use GRU or LSTM
    model.add(GRU(64))
    # and finally, we make a decision network
    model.add(Dense(1024, activation='relu'))
    model.add(Dropout(.5))
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(.5))
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(.5))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(nclasses, activation='softmax'))
    
    opt = Adam(lr=0.001)
    model.compile(optimizer=opt, loss=keras.losses.categorical_crossentropy, metrics='categorical_accuracy')
    return model





def train_test_valid(x,y):
    X_train_full, X_test, y_train_full, y_test = train_test_split(x, y, test_size=0.2, random_state=1)
    X_valid, X_train = X_train_full[:1], X_train_full
    y_valid, y_train = y_train_full[:1], y_train_full
    return X_train,X_test,X_valid,y_train,y_test,y_valid


    
def run_model(x,y,model,batch_size,epochs):
    X_train,X_test,X_valid,y_train,y_test,y_valid=train_test_valid(x,y)
    print(X_train.shape)
    history=model.fit_generator(
        batch_generator(X_train,y_train,batch_size),
        epochs=epochs,
        steps_per_epoch = int(X_train.shape[0]/batch_size))  
    score, acc = model.evaluate(X_test, y_test, batch_size=batch_size)
    print('Test score:', score)
    print('Test accuracy:', acc)
    print(history.history.keys())
    
    #  "Accuracy"
    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train', 'validation'], loc='upper left')
    plt.show()
    # "Loss"
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'validation'], loc='upper left')
    plt.show()
    return history
    



