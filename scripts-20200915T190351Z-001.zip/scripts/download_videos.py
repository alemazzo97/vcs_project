"""
Created on Mon Sep  7 12:06:03 2020

@author: alessio arcudi, alessandro mazzoni, alessandro padella
"""

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
This script exploit the packet pytube and keras video in order to
download and organize video from youtube.

-DATASET: it is downloaded from https://www.microsoft.com/en-us/research/project/ms-asl/.
          Sign language recognition is a challenging and often underestimated problem
          comprising multi-modal articulators (handshape, orientation, movement, upper
          body and face) that integrate asynchronously on multiple streams.
          Learning powerful statistical models in such a scenario requires much data,
          particularly to apply recent advances of the field. However, labeled data 
          is a scarce resource for sign language due to the enormous cost of transcribing 
          these unwritten languages. 
          In this case we managed to download 5000 different videos representing 100 different 
          "body language words" but we decided then to create a classification model using only 
          10 different classes with the highest number of videos representing them.
          
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#structural packets to move inside the different folders
import os
import json
import re

#packets used to download videos
from pytube import YouTube
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip

#set the pat to the main directory of google drive 
main_dir='C:/Users/padel/OneDrive/Desktop/videos'




""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
1) this function take in input:
     -[link]         the link for the youtube video
     -[dest_dir]     the path of the directory where the video will be saved

2) then it downloads the video 

3) as output gives:
     -[video path]   the path to the specific video 
"""

def video(link, dest_dir):
    try:
        v = YouTube(link)
        video_path = v.streams.get_by_itag(18).download(dest_dir)
        return video_path
    except:
        return None

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
1) This function take in input:
      -[train]       the microsoft dataset complete with all the url of the videos
      -[restart]     the index from which start the downloads
      -[main_dir]    the directory where to download all the videos
      -[label]       number of classes wanted
      
2) Create the directory for each class and downloads all the different video recalling the
  previous function video
  
"""

def download_video(train,restart=0,main_dir=main_dir,label=1001):    
    for i in range(len(train[restart:])):
        os.chdir(main_dir)
        if train[i]['label']<label:
            word=re.sub(' ','',train[i]["clean_text"])
            row=train[i]
            try:
               os.makedirs(main_dir+'/'+word)
            except:
               None
            dest_dir=main_dir+'/'+word
            os.chdir(dest_dir)
            vp=video(row['url'],dest_dir=dest_dir)        
            end_time=row["end_time"]
            start_time=row["start_time"]
            tname=word+str(i+restart)+'.mp4'
            try:
                ffmpeg_extract_subclip(vp, start_time, end_time, targetname=tname)
            except:
                None
            try:
                os.remove(vp)
            except:
                None
            print(i+restart)
            os.chdir(main_dir)
 
#if you run this script it will download the video from the dataset
if __name__=='__main__':
    #Directories used
    train='/Users/alessio/Documents/VCS_project/videos/train'
    valid= '/Users/alessio/Documents/VCS_project/videos/valid'
    test='/Users/alessio/Documents/VCS_project/videos/test'
    chose=[train,valid,test]
    typedir=input('train valid or test: ')
    
    #If work, with our huge dataset we must set use_frame_cache to False
    tra = json.load(open("MSASL_train.json"))
    te= json.load(open("MSASL_test.json"))
    val = json.load(open("MSASL_val.json"))
    chose2=[tra,val,te]
    restart=0         
    download_video(chose2[int(0*bool(typedir=='train')+1*bool(typedir=='valid')+2*bool(typedir=='test'))],label=101, restart=restart, main_dir=chose[0*(typedir=='train')+1*(typedir=='valid')+2*(typedir=='test')])     






































