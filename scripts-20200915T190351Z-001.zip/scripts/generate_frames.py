"""
Created on Mon Sep  7 12:06:03 2020

@author: alessio arcudi, alessandro mazzoni, alessandro padella
"""

import cv2
import numpy as np
import os
import glob


def generate_frames():
    x=input('test train or valid : ')
    os.chdir('/Users/alessio/Documents/VCS_project/videos/'+x)
    for i in glob.glob('*'):
      os.chdir('/Users/alessio/Documents/VCS_project/videos/'+x+'/{}'.format(i))
      os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/simple/{}'.format(i))
      os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/rgb/{}'.format(i))
      os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/over/{}'.format(i))
      for j in glob.glob('*'):
        name=j[:-4]
        cap = cv2.VideoCapture(j)
        os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/simple/{}/{}'.format(i,name))
        os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/rgb/{}/{}'.format(i,name))
        os.mkdir('/Users/alessio/Documents/VCS_project/frames/'+x+'/over/{}/{}'.format(i,name))
        ret, frame1 = cap.read()
        prvs = cv2.cvtColor(frame1,cv2.COLOR_BGR2GRAY)
        hsv = np.zeros_like(frame1)
        hsv[...,1] = 255
        a=0
        while(1):
          ret, frame2 = cap.read()
          try:
            next = cv2.cvtColor(frame2,cv2.COLOR_BGR2GRAY)
            flow = cv2.calcOpticalFlowFarneback(prvs,next, None, 0.5, 3, 15, 3, 5, 1.2, 0)
            mag, ang = cv2.cartToPolar(flow[...,0], flow[...,1])
            hsv[...,0] = ang*180/np.pi/2
            hsv[...,2] = cv2.normalize(mag,None,0,255,cv2.NORM_MINMAX)
            rgb = cv2.cvtColor(hsv,cv2.COLOR_HSV2BGR)
            #cv2_imshow(frame2)
            k = cv2.waitKey(30) & 0xff
            al=frame2.shape[0]
            lg=frame2.shape[1]
            frame2=frame2[int((al-240)/2)+1 : int(al-((al-240)/2))+1 ,int((lg-320)/2)+1 : int(lg-((lg-320)/2))+1]
            rgb=rgb[int((al-240)/2)+1 : int(al-((al-240)/2))+1 ,int((lg-320)/2)+1 : int(lg-((lg-320)/2))+1]
            cv2.imwrite('/Users/alessio/Documents/VCS_project/frames/'+x+'/simple/{}/{}/{}.png'.format(i,name,str(a)),frame2)
            cv2.imwrite('/Users/alessio/Documents/VCS_project/frames/'+x+'/rgb/{}/{}/{}.png'.format(i,name,str(a)),rgb)
            mash_up=cv2.addWeighted(rgb,0.95,frame2,0.35,0)
            cv2.imwrite('/Users/alessio/Documents/VCS_project/frames/'+x+'/over/{}/{}/{}.png'.format(i,name,str(a)),mash_up)
            a=a+1
            if k == 27:
              break
          except:
            break

if __name__=='__main__':
    generate_frames()


