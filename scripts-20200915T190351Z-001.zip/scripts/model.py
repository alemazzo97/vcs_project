#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 11 11:04:32 2020

@author: alessio
"""

import keras_models
import generate_dataset


#classe=eval(input('inserisci lista delle classi da classificare'))
#traintestorvalid=input('train, test or valid:  ')
#frametype=input('over,rgb or simple:  ')
#x,y=generate_dataset.generate_dataset(classe,traintestorvalid,frametype)

input_shape=(22, 240, 320, 3)
n_classes=len(classe)
batch_size=2
epochs=4

model=keras_models.action_model(input_shape,n_classes)
history=keras_models.run_model(x,y,model,batch_size,epochs)
