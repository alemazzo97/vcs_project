#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 12:06:03 2020

@author: alessio arcudi, alessandro mazzoni, alessandro padella
"""

import os
import glob
import numpy as np
import cv2
import pandas as pd



def label_dict(classes):
    d=dict()
    l=[0]*len(classes)
    for i in range(len(classes)):
        x=np.array(l)
        x[i]+=1
        d[classes[i]]=x
    return d


def generate_dataset(classes,traintestorvalid,frametype,n=23):
    d=label_dict(classes)
    train=[]
    y=[]
    os.chdir('/Users/alessio/Documents/VCS_project/frames/'+traintestorvalid+'/'+frametype)
    for i in classes:
        print(i)
        os.chdir('/Users/alessio/Documents/VCS_project/frames/'+traintestorvalid+'/'+frametype+'/{}'.format(i)) 
        #Sto in book
        for j in glob.glob('*'):
            l=[]#Lista che conterrà i frame come matrici(lunga esattamente 23)
            os.chdir('/Users/alessio/Documents/VCS_project/frames/'+traintestorvalid+'/'+frametype+'/{}/{}'.format(i,j))
            index=[int(x) for x in np.linspace(start=0, stop=len(glob.glob('*')), num=n, endpoint=True)]
            #sto nella cartella del video
            for k in index[:-1]:
                #Tutti i frame in una lista
                im=cv2.imread(str(k)+'.png')
                l.append(im)
            print(np.asarray(l).shape)
            train.append(np.asarray(l))
            y.append(d[i])
    train=np.asarray(train)
    y=np.array(y)
    print('shape dataset  ',train.shape)
    return train,y

if __name__=='__main__':
    classe=eval(input('inserisci lista delle classi da classificare'))
    traintestorvalid=input('train, test or valid:  ')
    frametype=input('over,rgb or simple:  ')
    x,y=generate_dataset(classe,traintestorvalid,frametype,n=23)
    





